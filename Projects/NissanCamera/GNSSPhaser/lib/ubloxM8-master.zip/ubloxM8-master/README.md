# ubloxM8
C++ Static library interfacing ublox GNSS receivers using the M8 UBX protocol
